package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val savedInput = prefs.getString("config_text", "100 100\nButton1 0.8 150 #FF0000\nhttp://google.com\nhttp://bing.com") ?: ""

        setContent {
            var input by remember { mutableStateOf(savedInput) }
            var showLogs by remember { mutableStateOf(false) }
            var logContent by remember { mutableStateOf("") }

            LaunchedEffect(input) {
                prefs.edit().putString("config_text", input).apply()
            }

            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                if (showLogs) {
                    Column(Modifier.padding(16.dp).fillMaxSize()) {
                        Text("App Logs", style = MaterialTheme.typography.headlineMedium)
                        Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
                            Text(logContent)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Button(onClick = { showLogs = false }) { Text("Back") }
                            Button(onClick = { 
                                val logFile = File(getExternalFilesDir(null), "app_logs.txt")
                                logFile.writeText("") // Clear logs
                                logContent = ""
                            }) { Text("Clear Logs") }
                        }
                    }
                } else {
                    Column(Modifier.padding(16.dp).fillMaxSize()) {
                        TextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            label = { Text("Config (X Y \\n Name Opacity Size Color \\n PressURL \\n ReleaseURL)") }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    val logFile = File(getExternalFilesDir(null), "app_logs.txt")
                                    logContent = if (logFile.exists()) logFile.readText() else "No logs yet."
                                    showLogs = true
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("View Logs")
                            }
                            Button(
                                onClick = {
                                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                    } else {
                                        val intent = Intent(this@MainActivity, FloatingButtonService::class.java).apply {
                                            putExtra("config", input)
                                        }
                                        stopService(Intent(this@MainActivity, FloatingButtonService::class.java))
                                        startService(intent)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Start")
                            }
                        }
                    }
                }
            }
        }
    }
}
