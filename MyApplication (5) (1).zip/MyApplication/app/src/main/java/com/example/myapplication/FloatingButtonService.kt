package com.example.myapplication

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FloatingButtonService : Service() {
    private var wm: WindowManager? = null
    private val buttons = mutableListOf<Button>()
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)
    private var logFile: File? = null

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        logFile = File(getExternalFilesDir(null), "app_logs.txt")
        logToFile("--- Service Session Started ---")
    }

    private fun logToFile(message: String) {
        val timestamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        val logLine = "[$timestamp] $message\n"
        Log.d("FloatingButton", message)
        try {
            logFile?.let { file ->
                FileOutputStream(file, true).use { it.write(logLine.toByteArray()) }
            }
        } catch (e: Exception) {
            Log.e("FloatingButton", "Failed to write log", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val config = intent?.getStringExtra("config") ?: ""
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        
        buttons.forEach { try { wm?.removeView(it) } catch (e: Exception) {} }
        buttons.clear()

        val lines = config.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val parts = line.split(Regex("[^0-9-]+")).filter { it.isNotBlank() }
            
            if (parts.size >= 2) {
                val x = parts[0].toIntOrNull()
                val y = parts[1].toIntOrNull()
                
                if (x != null && y != null) {
                    val nameLine = lines.getOrNull(i + 1) ?: ""
                    val pUrl = lines.getOrNull(i + 2) ?: ""
                    val rUrl = lines.getOrNull(i + 3) ?: ""
                    
                    createButton(x, y, nameLine, pUrl, rUrl)
                    i += 4 
                    continue
                }
            }
            i++
        }
        
        Toast.makeText(this, "Started ${buttons.size} buttons", Toast.LENGTH_SHORT).show()
        return START_STICKY
    }

    private fun createButton(x: Int, y: Int, nameLine: String, pUrl: String, rUrl: String) {
        val nameParts = nameLine.split(" ")
        val text = nameParts.getOrNull(0) ?: "Btn"
        val opacity = nameParts.getOrNull(1)?.toFloatOrNull() ?: 1.0f
        val size = nameParts.getOrNull(2)?.toIntOrNull() ?: WindowManager.LayoutParams.WRAP_CONTENT
        val colorHex = nameParts.getOrNull(3) ?: "#FF0000"

        val btn = Button(this).apply {
            this.text = text
            try {
                setBackgroundColor(Color.parseColor(colorHex))
            } catch (e: Exception) {
                setBackgroundColor(Color.RED)
            }
            setTextColor(Color.WHITE)
            alpha = opacity
            setAllCaps(false)
            
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { 
                        logToFile("UI: [$text] PRESS -> $pUrl")
                        v.isPressed = true
                        hit(pUrl, text, "PRESS") 
                    }
                    MotionEvent.ACTION_UP -> { 
                        logToFile("UI: [$text] RELEASE -> $rUrl")
                        v.isPressed = false
                        hit(rUrl, text, "RELEASE")
                        v.performClick()
                    }
                    MotionEvent.ACTION_CANCEL -> { v.isPressed = false }
                }
                true
            }
        }

        val params = WindowManager.LayoutParams(
            if (size > 0) size else WindowManager.LayoutParams.WRAP_CONTENT,
            if (size > 0) size else WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        
        try {
            wm?.addView(btn, params)
            buttons.add(btn)
        } catch (e: Exception) {
            logToFile("ERR: Failed to add $text: ${e.message}")
        }
    }

    private fun hit(u: String, btn: String, type: String) {
        val target = u.trim()
        if (target.isEmpty()) return
        val urlStr = if (!target.startsWith("http")) "http://$target" else target
        scope.launch {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(urlStr).openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                logToFile("NET: [$btn] $type Success (${conn.responseCode})")
            } catch (e: Exception) {
                logToFile("NET: [$btn] $type FAILED: ${e.message}")
            } finally { conn?.disconnect() }
        }
    }

    override fun onDestroy() {
        job.cancel()
        buttons.forEach { try { wm?.removeView(it) } catch (e: Exception) {} }
        super.onDestroy()
    }
}
