//compile using autohotkey windows , the key.ahk file to create key.exe and place in same path
const http = require('http');
const { execFile } = require('child_process');
const path = require('path');

const PORT = 5000;
const AHK = path.join(__dirname, 'key.exe');

const sendKey = (key, action) => {
  execFile(AHK, [key, action], (err) => {
    if (err) {
      console.error(`key error: ${key} ${action}`, err.message);
    }
  });
};

http.createServer((req, res) => {
  const p = new URL(req.url, 'http://localhost').searchParams;

  const key = p.get('key');
  const action = p.get('action');
  const time = p.get('time');

  if (!key || !action) {
    res.writeHead(400);
    return res.end('missing key or action');
  }

  sendKey(key, action);

  if (time) {
    setTimeout(() => sendKey(key, 'up'), parseInt(time));
  }

  res.writeHead(200);
  res.end('ok');
}).listen(PORT, () => {
  console.log(`listening on ${PORT}`);
});